var express = require("express");
var app =express();

app.use(express.static('public'));



app.get("/",function(req, res){
     res.render("index.ejs");
})

app.get("/about", function(req, res){
    res.render("about.ejs");
});

app.listen(3000, function(){
    console.log("Falis server running on port 3000...")
})